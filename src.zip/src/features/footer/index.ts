export * from './footer.schema'
