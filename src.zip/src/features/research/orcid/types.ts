export type CsvResearchRow = {
  title: string
  doi: string
  url: string
  publicationDate: string
  staffNames: string
  staffIds: string
  orcidIds: string
  categories: string
}

export type NameWithOrcid = {
  name: string
  orcid: string
  staffId: number
}

// Backwards-compatible alias for the previous scripts/exportResearch type name.
export type nameWithORcid = NameWithOrcid

export type ArticleOutput = {
  title: string
  doi: string | null
  url: string | null
  publicationDate: string | null
}

export type PerPersonOutputType = {
  name: string
  staffId: number
  articles: ArticleOutput[]
}

export type SharedArticle = {
  article: ArticleOutput
  people: string[]
  staffIds: number[]
}

export type OrcidDateValue = {
  value: number
}

export type OrcidStringValue = {
  value: string
}

export type OrcidNullableStringValue = OrcidStringValue | null

export type OrcidExternalId = {
  'external-id-type': string
  'external-id-value': string
  'external-id-normalized': {
    value: string
    transient: boolean
  } | null
  'external-id-normalized-error': string | null
  'external-id-url': OrcidNullableStringValue
  'external-id-relationship': string
}

export type OrcidExternalIds = {
  'external-id': OrcidExternalId[]
}

export type OrcidSource = {
  'source-orcid': {
    uri: string
    path: string
    host: string
  } | null

  'source-client-id': {
    uri: string
    path: string
    host: string
  } | null

  'source-name': OrcidStringValue | null

  'assertion-origin-orcid': {
    uri: string
    path: string
    host: string
  } | null

  'assertion-origin-client-id': {
    uri: string
    path: string
    host: string
  } | null

  'assertion-origin-name': OrcidStringValue | null
}

export type OrcidTitle = {
  title: OrcidStringValue
  subtitle: OrcidNullableStringValue
  'translated-title': OrcidNullableStringValue
}

export type OrcidPublicationDate = {
  year: OrcidStringValue | null
  month: OrcidStringValue | null
  day: OrcidStringValue | null
}

export type OrcidWorkSummary = {
  'put-code': number
  'created-date': OrcidDateValue
  'last-modified-date': OrcidDateValue
  source: OrcidSource
  title: OrcidTitle
  'external-ids': OrcidExternalIds
  url: OrcidNullableStringValue
  type: string
  'publication-date': OrcidPublicationDate
  'journal-title': OrcidNullableStringValue
  visibility: string
  path: string
  'display-index': string
}

export type OrcidWorkGroup = {
  'last-modified-date': OrcidDateValue
  'external-ids': OrcidExternalIds
  'work-summary': OrcidWorkSummary[]
}

export type OrcidWorksResponse = {
  'last-modified-date': OrcidDateValue
  group: OrcidWorkGroup[]
}

export type ResearchExportProgressStage =
  | 'staff'
  | 'orcid'
  | 'rows'
  | 'categories'
  | 'csv'
  | 'storage'
  | 'complete'

export type ResearchExportProgressEvent = {
  progress: number
  stage: ResearchExportProgressStage
  status: string
  current?: number
  total?: number
}

export type ResearchExportProgressOptions = {
  onProgress?: (event: ResearchExportProgressEvent) => void
  signal?: AbortSignal
}
